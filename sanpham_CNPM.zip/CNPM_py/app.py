from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import bcrypt

app = Flask(__name__)
app.secret_key = "fithub_secret"

server   = r"MINHLUONG\MINHLUONG"
database = "CNPM2"
username = "sa"
password = "123456"

app.config['SQLALCHEMY_DATABASE_URI'] = (
    "mssql+pyodbc://sa:123456@MINHLUONG\\MINHLUONG/"
    "CNPM2?driver=ODBC Driver 17 for SQL Server"
)

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config['JSON_AS_ASCII'] = False
app.config['JSONIFY_MIMETYPE'] = "application/json; charset=utf-8"
import pyodbc

conn = pyodbc.connect(
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=MINHLUONG\\MINHLUONG;"
    "DATABASE=CNPM2;"
    "UID=sa;"
    "PWD=123456;"
)
db = SQLAlchemy(app)
def execute_query(query, params=None):
    cur = conn.cursor()
    if params:
        cur.execute(query, params)
    else:
        cur.execute(query)
    rows = cur.fetchall()
    return rows

def execute_non_query(query, params=None):
    cur = conn.cursor()
    if params:
        cur.execute(query, params)
    else:
        cur.execute(query)
    conn.commit()


# ==================================================
#  MODEL KHỚP 100% BẢNG TRONG SQL SERVER CNPM2
# ==================================================

class User(db.Model):
    __tablename__ = "Users"

    user_id    = db.Column(db.Integer, primary_key=True)
    full_name  = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(100), nullable=False)
    mssv       = db.Column(db.String(50), nullable=False)
    password   = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime)
    status     = db.Column(db.String(20))

    bmi_history   = db.relationship("BMIHistory", backref="user", lazy=True)
    workout_plans = db.relationship("WorkoutPlan", backref="user", lazy=True)
    bookings      = db.relationship("CourtBooking", backref="user", lazy=True)
    orders        = db.relationship("Order", backref="user", lazy=True)


class BMIHistory(db.Model):
    __tablename__ = "BMIHistory"

    id        = db.Column(db.Integer, primary_key=True)
    user_id   = db.Column(db.Integer, db.ForeignKey("Users.user_id"))
    height    = db.Column(db.Float)
    weight    = db.Column(db.Float)
    bmi       = db.Column(db.Float)
    status    = db.Column(db.String(50))
    created_at = db.Column(db.DateTime)


class Workout(db.Model):
    __tablename__ = "Workouts"

    workout_id = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(150))
    sport_type = db.Column(db.String(50))
    goal       = db.Column(db.String(200))
    difficulty = db.Column(db.String(50))
    calories   = db.Column(db.Integer)
    video_url  = db.Column(db.String(255))
    bmi_group  = db.Column(db.String(20))


class WorkoutPlan(db.Model):
    __tablename__ = "WorkoutPlan"

    plan_id    = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("Users.user_id"))
    plan_name  = db.Column(db.String(150))
    created_at = db.Column(db.DateTime)

    details = db.relationship("WorkoutPlanDetails", backref="plan", lazy=True)


class WorkoutPlanDetails(db.Model):
    __tablename__ = "WorkoutPlanDetails"

    detail_id   = db.Column(db.Integer, primary_key=True)
    plan_id     = db.Column(db.Integer, db.ForeignKey("WorkoutPlan.plan_id"))
    day_of_week = db.Column(db.String(20))
    workout_id  = db.Column(db.Integer, db.ForeignKey("Workouts.workout_id"))
    workout = db.relationship("Workout")


class Partner(db.Model):
    __tablename__ = "Partners"

    partner_id   = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(150))
    email        = db.Column(db.String(100))
    phone        = db.Column(db.String(50))
    password     = db.Column(db.String(200))
    created_at   = db.Column(db.DateTime)
    status       = db.Column(db.String(20))

    products = db.relationship("Product", backref="partner", lazy=True)
    courts   = db.relationship("Court", backref="partner", lazy=True)


class Court(db.Model):
    __tablename__ = "Courts"

    court_id      = db.Column(db.Integer, primary_key=True)
    partner_id    = db.Column(db.Integer, db.ForeignKey("Partners.partner_id"))
    name          = db.Column(db.String(150))
    address       = db.Column(db.String(200))
    sport_type    = db.Column(db.String(50))
    price_per_hour = db.Column(db.Float)
    open_time     = db.Column(db.String(20))
    close_time    = db.Column(db.String(20))
    status        = db.Column(db.String(20))
    created_at    = db.Column(db.DateTime)

    bookings = db.relationship("CourtBooking", backref="court", lazy=True)


class CourtBooking(db.Model):
    __tablename__ = "CourtBooking"

    booking_id   = db.Column(db.Integer, primary_key=True)
    user_id      = db.Column(db.Integer, db.ForeignKey("Users.user_id"))
    court_id     = db.Column(db.Integer, db.ForeignKey("Courts.court_id"))
    booking_date = db.Column(db.Date)
    time_slot    = db.Column(db.String(50))
    status       = db.Column(db.String(20))
    created_at   = db.Column(db.DateTime)


class Product(db.Model):
    __tablename__ = "Products"

    product_id = db.Column(db.Integer, primary_key=True)
    partner_id = db.Column(db.Integer, db.ForeignKey("Partners.partner_id"))
    name       = db.Column(db.String(150))
    price      = db.Column(db.Float)
    quantity   = db.Column(db.Integer)
    type       = db.Column(db.String(20))
    description = db.Column(db.String(255))
    status     = db.Column(db.String(20))
    created_at = db.Column(db.DateTime)

    orders = db.relationship("Order", backref="product", lazy=True)


class Order(db.Model):
    __tablename__ = "Orders"

    order_id    = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey("Users.user_id"))
    product_id  = db.Column(db.Integer, db.ForeignKey("Products.product_id"))
    quantity    = db.Column(db.Integer)
    rent_days   = db.Column(db.Integer)
    total_price = db.Column(db.Float)
    created_at  = db.Column(db.DateTime)


class Admin(db.Model):
    __tablename__ = "Admins"

    admin_id   = db.Column(db.Integer, primary_key=True)
    username   = db.Column(db.String(50))
    password   = db.Column(db.String(200))
    created_at = db.Column(db.DateTime)


class SupportMessage(db.Model):
    __tablename__ = 'SupportMessages'
    id = db.Column(db.Integer, primary_key=True)
    user_type = db.Column(db.String(20))
    user_id = db.Column(db.Integer)
    name = db.Column(db.String(150))
    email = db.Column(db.String(150))
    message = db.Column(db.String(2000))
    created_at = db.Column(db.DateTime)

# ==================================================
#  HÀM TIỆN ÍCH
# ==================================================

def current_user():
    if "user_id" in session:
        return User.query.get(session["user_id"])
    return None

def hash_pw(pw: str):
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

def check_pw(pw: str, hashed: str):
    return bcrypt.checkpw(pw.encode(), hashed.encode())


# --------------------
#  User change password + support
# --------------------

@app.route('/user/change_password', methods=['GET', 'POST'])
def user_change_password():
    user = current_user()
    if not user:
        return redirect(url_for('login'))

    if request.method == 'POST':
        old = request.form.get('old_password')
        new = request.form.get('new_password')
        confirm = request.form.get('confirm_password')

        if not check_pw(old, user.password):
            flash('Mật khẩu cũ không đúng.', 'danger')
            return render_template('user_change_password.html', user=user)
        if new != confirm:
            flash('Mật khẩu mới và xác nhận không khớp.', 'danger')
            return render_template('user_change_password.html', user=user)

        user.password = hash_pw(new)
        db.session.commit()
        flash('Đổi mật khẩu thành công.', 'success')
        return redirect(url_for('user_home'))

    return render_template('user_change_password.html', user=user)


@app.route('/user/support', methods=['GET', 'POST'])
def user_support():
    user = current_user()
    if not user:
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form.get('name') or user.full_name
        email = request.form.get('email') or user.email
        msg = request.form.get('message')

        # try to save to DB, otherwise log to file
        try:
            execute_non_query(
                "INSERT INTO SupportMessages (user_type, user_id, name, email, message, created_at) VALUES (?, ?, ?, ?, ?, GETDATE())",
                ('user', user.user_id, name, email, msg)
            )
        except Exception:
            # fallback: append to local file
            with open('support_messages.log', 'a', encoding='utf-8') as f:
                f.write(f"USER\t{user.user_id}\t{name}\t{email}\t{msg}\t{datetime.now()}\n")

        flash('Cảm ơn! Chúng tôi đã nhận yêu cầu của bạn.', 'success')
        return redirect(url_for('user_home'))

    return render_template('user_support.html', user=user)


# --------------------
#  Partner change password + support
# --------------------

@app.route('/partner/change_password', methods=['GET', 'POST'])
def partner_change_password():
    if 'partner_id' not in session:
        return redirect(url_for('partner_login'))
    p = Partner.query.get(session['partner_id'])

    if request.method == 'POST':
        old = request.form.get('old_password')
        new = request.form.get('new_password')
        confirm = request.form.get('confirm_password')

        if not check_pw(old, p.password):
            flash('Mật khẩu cũ không đúng.', 'danger')
            return render_template('partner_change_password.html', partner=p)
        if new != confirm:
            flash('Mật khẩu mới và xác nhận không khớp.', 'danger')
            return render_template('partner_change_password.html', partner=p)

        p.password = hash_pw(new)
        db.session.commit()
        flash('Đổi mật khẩu thành công.', 'success')
        return redirect(url_for('partner_home'))

    return render_template('partner_change_password.html', partner=p)


@app.route('/partner/support', methods=['GET', 'POST'])
def partner_support():
    if 'partner_id' not in session:
        return redirect(url_for('partner_login'))
    p = Partner.query.get(session['partner_id'])

    if request.method == 'POST':
        name = request.form.get('name') or p.company_name
        email = request.form.get('email') or p.email
        msg = request.form.get('message')

        try:
            execute_non_query(
                "INSERT INTO SupportMessages (user_type, user_id, name, email, message, created_at) VALUES (?, ?, ?, ?, ?, GETDATE())",
                ('partner', p.partner_id, name, email, msg)
            )
        except Exception:
            with open('support_messages.log', 'a', encoding='utf-8') as f:
                f.write(f"PARTNER\t{p.partner_id}\t{name}\t{email}\t{msg}\t{datetime.now()}\n")

        flash('Cảm ơn! Yêu cầu của bạn đã được gửi.', 'success')
        return redirect(url_for('partner_home'))

    return render_template('partner_support.html', partner=p)

# ==================================================
#   ROUTE CHUNG: LOGIN / REGISTER
# ==================================================

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("user_home"))
    return redirect(url_for("login"))

# ==================================================
#  USER HOME
# ==================================================
@app.route("/user/home")
def user_home():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    return render_template("user_home.html", user=user)

# ==========================
#       USER BMI
# ==========================
@app.route("/user/bmi", methods=["GET", "POST"])
def user_bmi():
    if "user_id" not in session:
        return redirect("/login")

    user_id = session["user_id"]

    if request.method == "POST":
        height = float(request.form["height"])
        weight = float(request.form["weight"])

        bmi = round(weight / (height * height), 2)

        if bmi < 18.5:
            status = "Gầy"
        elif bmi < 25:
            status = "Bình thường"
        elif bmi < 30:
            status = "Thừa cân"
        else:
            status = "Béo phì"

        # Lưu vào DB
        execute_non_query(
            "INSERT INTO BMIHistory (user_id, height, weight, bmi, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, GETDATE())",
            (user_id, height, weight, bmi, status)
        )

        # Chuyển sang trang gợi ý bài tập dựa vào BMI vừa tính
        return redirect("/user/workouts")

    # Nếu GET → hiển thị lịch sử BMI
    history = execute_query(
        "SELECT height, weight, bmi, status, created_at "
        "FROM BMIHistory WHERE user_id=? ORDER BY created_at DESC",
        (user_id,)
    )

    formatted_history = []
    for h in history:
        formatted_history.append({
            "height": h[0],
            "weight": h[1],
            "bmi": h[2],
            "status": h[3],
            "created_at": h[4]
        })

    return render_template("user_bmi.html", history=formatted_history)



# ==========================
#     USER WORKOUTS
# ==========================
@app.route("/user/workouts")
def user_workouts():
    if "user_id" not in session:
        return redirect("/login")

    user_id = session["user_id"]

    # ---- Lấy BMI mới nhất ----
    row = execute_query(
        "SELECT TOP 1 bmi FROM BMIHistory WHERE user_id=? ORDER BY created_at DESC",
        (user_id,)
    )

    if not row:
        return render_template("user_workouts.html", bmi=None, workouts=[])

    bmi = float(row[0][0])

    # ---- Xác định nhóm bài tập ----
    if bmi < 18.5:
        group_id = 1
    elif bmi < 25:
        group_id = 2
    elif bmi < 30:
        group_id = 3
    else:
        group_id = 4

    workouts = execute_query(
        "SELECT name, goal, difficulty, calories, video_url "
        "FROM Workouts WHERE bmi_group=?",
        (group_id,)
    )

    return render_template("user_workouts.html", bmi=bmi, workouts=workouts)

@app.route("/user/plans")
def user_plans():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    plans = WorkoutPlan.query.filter_by(user_id=user.user_id).all()

    return render_template("user_plans.html", user=user, plans=plans)
@app.route("/user/plans/create", methods=["GET", "POST"])
def create_plan():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    if request.method == "POST":
        name = request.form["plan_name"]

        p = WorkoutPlan(
            user_id=user.user_id,
            plan_name=name,
            created_at=datetime.now()
        )
        db.session.add(p)
        db.session.commit()

        flash("Tạo kế hoạch thành công!", "success")
        return redirect(url_for("user_plans"))

    return render_template("plan_create.html", user=user)
@app.route("/user/plans/<int:plan_id>/add", methods=["GET", "POST"])
def plan_add_workout(plan_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    plan = WorkoutPlan.query.filter_by(plan_id=plan_id, user_id=user.user_id).first()
    if not plan:
        flash("Không tìm thấy kế hoạch!", "danger")
        return redirect(url_for("user_plans"))

    workouts = Workout.query.all()

    if request.method == "POST":
        day  = request.form.get("day_of_week")
        try:
            wid = int(request.form.get("workout_id"))
        except (TypeError, ValueError):
            flash("Vui lòng chọn bài tập hợp lệ.", "danger")
            return redirect(url_for("plan_add_workout", plan_id=plan.plan_id))

        # Optional: validate day value to avoid unexpected input
        allowed_days = ["Thứ Hai","Thứ Ba","Thứ Tư","Thứ Năm","Thứ Sáu","Thứ Bảy","Chủ Nhật",
                        "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        if day not in allowed_days:
            flash("Vui lòng chọn ngày hợp lệ.", "danger")
            return redirect(url_for("plan_add_workout", plan_id=plan.plan_id))

        detail = WorkoutPlanDetails(
            plan_id=plan.plan_id,
            day_of_week=day,
            workout_id=wid
        )
        db.session.add(detail)
        db.session.commit()

        flash("Đã thêm bài tập vào kế hoạch!", "success")
        return redirect(url_for("user_plans"))

    return render_template("plan_add.html", user=user, plan=plan, workouts=workouts)
@app.route("/user/plans/<int:plan_id>")
def plan_details(plan_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    plan = WorkoutPlan.query.filter_by(plan_id=plan_id, user_id=user.user_id).first()
    if not plan:
        flash("Không tìm thấy kế hoạch!", "danger")
        return redirect(url_for("user_plans"))

    details = WorkoutPlanDetails.query.filter_by(plan_id=plan.plan_id).all()

    return render_template("plan_details.html", user=user, plan=plan, details=details)


@app.route("/user/plans/delete/<int:plan_id>", methods=["POST"])
def delete_plan(plan_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    plan = WorkoutPlan.query.filter_by(plan_id=plan_id, user_id=user.user_id).first()
    if not plan:
        flash("Không tìm thấy kế hoạch hoặc bạn không có quyền xóa.", "danger")
        return redirect(url_for("user_plans"))

    # Delete related details first to be safe
    try:
        WorkoutPlanDetails.query.filter_by(plan_id=plan.plan_id).delete()
        db.session.delete(plan)
        db.session.commit()
        flash("Đã xóa kế hoạch.", "success")
    except Exception:
        db.session.rollback()
        flash("Xóa kế hoạch thất bại.", "danger")

    return redirect(url_for("user_plans"))
@app.route("/user/courts")
def user_courts():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    courts = Court.query.filter_by(status="approved").all()

    return render_template("user_courts.html", user=user, courts=courts)
@app.route("/user/courts/<int:court_id>")
def court_detail(court_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    court = Court.query.filter_by(court_id=court_id, status="approved").first()

    if not court:
        flash("Sân không tồn tại!", "danger")
        return redirect(url_for("user_courts"))

    # compute availability for next 7 days
    try:
        open_h = int(court.open_time.split(":")[0])
        close_h = int(court.close_time.split(":")[0])
    except Exception:
        open_h, close_h = 8, 20

    slots = [f"{h:02d}:00-{h+1:02d}:00" for h in range(open_h, close_h)]

    days = []
    from datetime import date, timedelta
    today = date.today()
    for i in range(7):
        d = today + timedelta(days=i)
        bks = CourtBooking.query.filter_by(court_id=court.court_id, booking_date=d, status='booked').all()
        booked = []
        for b in bks:
            booked.append({
                "time_slot": b.time_slot,
                "user_name": getattr(b.user, "full_name", "Người dùng"),
            })
        booked_slots = [b["time_slot"] for b in booked]
        free = [s for s in slots if s not in booked_slots]
        days.append({"date": d, "booked": booked, "free": free})

    return render_template("court_detail.html", user=user, court=court, days=days)
@app.route("/user/courts/book/<int:court_id>", methods=["GET", "POST"])
def book_court(court_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    court = Court.query.filter_by(court_id=court_id, status="approved").first()
    if not court:
        flash("Sân không tồn tại!", "danger")
        return redirect(url_for("user_courts"))

    if request.method == "POST":

        # NHẬN DỮ LIỆU ĐÚNG TÊN
        date_str = request.form.get("booking_date")
        timeslot = request.form.get("time_slot")

        # Parse date string (HTML date input -> YYYY-MM-DD) to date object
        try:
            booking_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        except Exception:
            flash("Ngày đặt không hợp lệ.", "danger")
            return redirect(url_for("book_court", court_id=court_id))

        if not date_str or not timeslot:
            flash("Vui lòng chọn đầy đủ ngày và giờ!", "danger")
            return redirect(url_for("book_court", court_id=court_id))

        # KIỂM TRA TRÙNG
        exist = CourtBooking.query.filter_by(
            court_id=court_id,
            booking_date=booking_date,
            time_slot=timeslot
        ).first()

        if exist:
            flash("Khung giờ này đã có người đặt!", "danger")
            return redirect(url_for("book_court", court_id=court_id))

        booking = CourtBooking(
            user_id=user.user_id,
            court_id=court_id,
            booking_date=booking_date,
            time_slot=timeslot,
            status="booked",
            created_at=datetime.now()
        )
        db.session.add(booking)
        db.session.commit()

        flash("Đặt sân thành công!", "success")
        return redirect(url_for("user_bookings"))

    return render_template("court_book.html", user=user, court=court)

@app.route("/user/bookings")
def user_bookings():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    bookings = CourtBooking.query.filter_by(user_id=user.user_id, status="booked").order_by(
        CourtBooking.created_at.desc()
    ).all()

    return render_template("user_bookings.html", user=user, bookings=bookings)


@app.route("/user/bookings/cancel/<int:booking_id>", methods=["POST"])
def cancel_booking(booking_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    booking = CourtBooking.query.get(booking_id)
    if not booking or booking.user_id != user.user_id:
        flash("Không tìm thấy đặt sân hoặc bạn không có quyền hủy.", "danger")
        return redirect(url_for("user_bookings"))

    # Use the raw pyodbc helper to update the DB directly to avoid possible session/connection mismatch
    try:
        execute_non_query(
            "UPDATE CourtBooking SET status=? WHERE booking_id=?",
            ("cancelled", booking_id)
        )
        flash("Đã hủy đặt sân.", "success")
    except Exception:
        flash("Hủy đặt sân thất bại.", "danger")

    return redirect(url_for("user_bookings"))
@app.route("/user/shop")
def user_shop():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    products = Product.query.filter_by(status="approved").all()

    return render_template("user_shop.html", user=user, products=products)
@app.route("/user/shop/<int:product_id>")
def product_detail(product_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    product = Product.query.filter_by(product_id=product_id, status="approved").first()

    if not product:
        flash("Sản phẩm không tồn tại!", "danger")
        return redirect(url_for("user_shop"))

    # seller info available via relationship `product.partner`
    return render_template("product_detail.html", user=user, product=product)
@app.route("/user/shop/buy/<int:product_id>", methods=["GET", "POST"])
def buy_product(product_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    product = Product.query.filter_by(product_id=product_id, status="approved").first()
    if not product:
        flash("Sản phẩm không tồn tại!", "danger")
        return redirect(url_for("user_shop"))

    if request.method == "POST":
        qty = int(request.form["quantity"])
        if qty <= 0:
            flash("Số lượng phải lớn hơn 0!", "danger")
            return redirect(url_for("buy_product", product_id=product_id))

        # Check stock if product.quantity exists
        stock = getattr(product, "quantity", None)
        if stock is not None and qty > stock:
            flash("Số lượng trong kho không đủ.", "danger")
            return redirect(url_for("buy_product", product_id=product_id))

        total = qty * product.price

        order = Order(
            user_id=user.user_id,
            product_id=product_id,
            quantity=qty,
            rent_days=None,
            total_price=total,
            created_at=datetime.now()
        )
        db.session.add(order)
        db.session.commit()

        # decrement stock if field exists
        try:
            if getattr(product, "quantity", None) is not None:
                product.quantity = product.quantity - qty
                if product.quantity < 0:
                    product.quantity = 0
                db.session.commit()
        except Exception:
            db.session.rollback()

        flash("Mua hàng thành công!", "success")
        return redirect(url_for("user_orders"))

    return render_template("product_buy.html", user=user, product=product)
@app.route("/user/shop/rent/<int:product_id>", methods=["GET", "POST"])
def rent_product(product_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    product = Product.query.filter_by(product_id=product_id, status="approved").first()
    if not product:
        flash("Sản phẩm không tồn tại!", "danger")
        return redirect(url_for("user_shop"))

    if request.method == "POST":
        days = int(request.form["rent_days"])
        if days <= 0:
            flash("Số ngày phải lớn hơn 0!", "danger")
            return redirect(url_for("rent_product", product_id=product_id))

        # check stock
        stock = getattr(product, "quantity", None)
        if stock is not None and stock <= 0:
            flash("Sản phẩm đã hết hàng.", "danger")
            return redirect(url_for("product_detail", product_id=product_id))

        total = days * product.price

        order = Order(
            user_id=user.user_id,
            product_id=product_id,
            quantity=None,
            rent_days=days,
            total_price=total,
            created_at=datetime.now()
        )
        db.session.add(order)
        db.session.commit()

        # decrement stock by 1 when rented (if tracked)
        try:
            if getattr(product, "quantity", None) is not None:
                product.quantity = max(0, product.quantity - 1)
                db.session.commit()
        except Exception:
            db.session.rollback()

        flash("Thuê thành công!", "success")
        return redirect(url_for("user_orders"))

    return render_template("product_rent.html", user=user, product=product)
@app.route("/user/orders")
def user_orders():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    orders = Order.query.filter_by(user_id=user.user_id).order_by(
        Order.created_at.desc()
    ).all()

    return render_template("user_orders.html", user=user, orders=orders)
@app.route("/partner/login", methods=["GET", "POST"])
def partner_login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        partner = Partner.query.filter_by(email=email).first()

        if partner and check_pw(password, partner.password):
                if getattr(partner, "status", "active") != "active":
                    flash("Tài khoản đối tác đã bị khóa.", "danger")
                    return render_template("partner_login.html")

                session["partner_id"] = partner.partner_id
                session["role"] = "partner"
                return redirect(url_for("partner_home"))

        flash("Sai email hoặc mật khẩu!", "danger")

    return render_template("partner_login.html")
@app.route("/partner/home")
def partner_home():
    if "partner_id" not in session:
        return redirect(url_for("partner_login"))

    partner = Partner.query.get(session["partner_id"])
    products = Product.query.filter_by(partner_id=partner.partner_id).all()
    courts   = Court.query.filter_by(partner_id=partner.partner_id).all()

    return render_template("partner_home.html", partner=partner, products=products, courts=courts)
@app.route("/partner/product/add", methods=["GET","POST"])
def partner_add_product():
    if "partner_id" not in session:
        return redirect(url_for("partner_login"))

    partner_id = session["partner_id"]

    if request.method == "POST":
        name = request.form["name"]
        price = float(request.form["price"])
        type_ = request.form["type"]
        desc = request.form["description"]
        # optional quantity field
        try:
            qty = int(request.form.get("quantity", "0"))
        except (TypeError, ValueError):
            qty = None

        p = Product(
            partner_id = partner_id,
            name = name,
            price = price,
            quantity = qty,
            type = type_,
            description = desc,
            status = "pending",
            created_at = datetime.now()
        )
        db.session.add(p)
        db.session.commit()

        flash("Đăng sản phẩm thành công! Chờ admin duyệt.", "success")
        return redirect(url_for("partner_home"))

    return render_template("partner_add_product.html")


@app.route('/partner/product/edit/<int:pid>', methods=['GET', 'POST'])
def partner_edit_product(pid):
    if 'partner_id' not in session:
        return redirect(url_for('partner_login'))

    partner_id = session['partner_id']
    p = Product.query.filter_by(product_id=pid, partner_id=partner_id).first()
    if not p:
        flash('Sản phẩm không tồn tại hoặc bạn không có quyền.', 'danger')
        return redirect(url_for('partner_home'))

    if request.method == 'POST':
        p.name = request.form.get('name')
        try:
            p.price = float(request.form.get('price'))
        except Exception:
            p.price = p.price
        p.type = request.form.get('type')
        p.description = request.form.get('description')
        try:
            q = int(request.form.get('quantity'))
            p.quantity = q
        except Exception:
            pass
        db.session.commit()
        flash('Cập nhật sản phẩm thành công.', 'success')
        return redirect(url_for('partner_home'))

    return render_template('partner_edit_product.html', product=p)


@app.route('/partner/product/delete/<int:pid>', methods=['POST'])
def partner_delete_product(pid):
    if 'partner_id' not in session:
        return redirect(url_for('partner_login'))

    partner_id = session['partner_id']
    p = Product.query.filter_by(product_id=pid, partner_id=partner_id).first()
    if not p:
        flash('Sản phẩm không tồn tại hoặc bạn không có quyền.', 'danger')
        return redirect(url_for('partner_home'))

    try:
        db.session.delete(p)
        db.session.commit()
        flash('Đã xóa sản phẩm.', 'success')
    except Exception:
        db.session.rollback()
        flash('Xóa sản phẩm thất bại.', 'danger')

    return redirect(url_for('partner_home'))
@app.route("/partner/court/add", methods=["GET","POST"])
def partner_add_court():
    if "partner_id" not in session:
        return redirect(url_for("partner_login"))

    partner_id = session["partner_id"]

    if request.method == "POST":
        name = request.form["name"]
        addr = request.form["address"]
        sport = request.form["sport_type"]
        price = float(request.form["price_per_hour"])
        open_t = request.form["open_time"]
        close_t = request.form["close_time"]

        c = Court(
            partner_id=partner_id,
            name=name,
            address=addr,
            sport_type=sport,
            price_per_hour=price,
            open_time=open_t,
            close_time=close_t,
            status="pending",
            created_at=datetime.now()
        )
        db.session.add(c)
        db.session.commit()

        flash("Đăng sân thành công! Chờ admin duyệt.", "success")
        return redirect(url_for("partner_home"))

    return render_template("partner_add_court.html")


@app.route('/partner/court/edit/<int:cid>', methods=['GET', 'POST'])
def partner_edit_court(cid):
    if 'partner_id' not in session:
        return redirect(url_for('partner_login'))

    partner_id = session['partner_id']
    c = Court.query.filter_by(court_id=cid, partner_id=partner_id).first()
    if not c:
        flash('Sân không tồn tại hoặc bạn không có quyền.', 'danger')
        return redirect(url_for('partner_home'))

    if request.method == 'POST':
        c.name = request.form.get('name')
        c.address = request.form.get('address')
        c.sport_type = request.form.get('sport_type')
        try:
            c.price_per_hour = float(request.form.get('price_per_hour'))
        except Exception:
            pass
        c.open_time = request.form.get('open_time')
        c.close_time = request.form.get('close_time')
        db.session.commit()
        flash('Cập nhật sân thành công.', 'success')
        return redirect(url_for('partner_home'))

    return render_template('partner_edit_court.html', court=c)


@app.route('/partner/court/delete/<int:cid>', methods=['POST'])
def partner_delete_court(cid):
    if 'partner_id' not in session:
        return redirect(url_for('partner_login'))

    partner_id = session['partner_id']
    c = Court.query.filter_by(court_id=cid, partner_id=partner_id).first()
    if not c:
        flash('Sân không tồn tại hoặc bạn không có quyền.', 'danger')
        return redirect(url_for('partner_home'))

    try:
        db.session.delete(c)
        db.session.commit()
        flash('Đã xóa sân.', 'success')
    except Exception:
        db.session.rollback()
        flash('Xóa sân thất bại.', 'danger')

    return redirect(url_for('partner_home'))
@app.route("/partner/bookings")
def partner_bookings():
    if "partner_id" not in session:
        return redirect(url_for("partner_login"))

    partner_id = session["partner_id"]

    bookings = CourtBooking.query.join(Court).filter(
        Court.partner_id == partner_id
    ).order_by(CourtBooking.booking_date.desc()).all()

    return render_template("partner_bookings.html", bookings=bookings)
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        admin = Admin.query.filter_by(username=username).first()

        if admin and check_pw(password, admin.password):
            session["admin_id"] = admin.admin_id
            session["role"] = "admin"
            return redirect(url_for("admin_home"))

        flash("Sai tài khoản hoặc mật khẩu!", "danger")

    return render_template("admin_login.html")
@app.route("/admin/home")
def admin_home():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    stats = {
        "users": User.query.count(),
        "partners": Partner.query.count(),
        "products": Product.query.count(),
        "courts": Court.query.count(),
        "orders": Order.query.count(),
    }

    return render_template("admin_home.html", stats=stats)
@app.route("/admin/users")
def admin_users():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    users = User.query.all()
    return render_template("admin_users.html", users=users)
@app.route("/admin/users/lock/<int:user_id>")
def admin_user_lock(user_id):
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    user = User.query.get(user_id)
    user.status = "blocked"
    db.session.commit()
    flash("Đã khóa tài khoản.", "warning")

    return redirect(url_for("admin_users"))
@app.route("/admin/users/unlock/<int:user_id>")
def admin_user_unlock(user_id):
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    user = User.query.get(user_id)
    user.status = "active"
    db.session.commit()
    flash("Đã mở khóa tài khoản.", "success")

    return redirect(url_for("admin_users"))
@app.route("/admin/partners")
def admin_partners():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    partners = Partner.query.all()
    return render_template("admin_partners.html", partners=partners)


@app.route("/admin/partners/create", methods=["GET", "POST"])
def admin_partner_create():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    if request.method == "POST":
        company_name = request.form.get("company_name")
        email = request.form.get("email")
        phone = request.form.get("phone")
        password_raw = request.form.get("password")

        if not company_name or not email or not password_raw:
            flash("Vui lòng điền đầy đủ thông tin bắt buộc.", "danger")
            return render_template("admin_partner_create.html")

        # check duplicate email
        if Partner.query.filter_by(email=email).first():
            flash("Email này đã tồn tại.", "danger")
            return render_template("admin_partner_create.html")

        hashed = hash_pw(password_raw)
        p = Partner(
            company_name=company_name,
            email=email,
            phone=phone,
            password=hashed,
            created_at=datetime.now(),
            status="active"
        )
        db.session.add(p)
        db.session.commit()

        flash("Tạo đối tác thành công!", "success")
        return redirect(url_for("admin_partners"))

    return render_template("admin_partner_create.html")
@app.route("/admin/partners/lock/<int:pid>")
def admin_partner_lock(pid):
    partner = Partner.query.get(pid)
    partner.status = "blocked"
    db.session.commit()
    flash("Đã khóa đối tác!", "warning")
    return redirect(url_for("admin_partners"))
@app.route("/admin/partners/unlock/<int:pid>")
def admin_partner_unlock(pid):
    partner = Partner.query.get(pid)
    partner.status = "active"
    db.session.commit()
    flash("Đã mở khóa đối tác!", "success")
    return redirect(url_for("admin_partners"))
@app.route("/admin/products")
def admin_products():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    products = Product.query.filter_by(status="pending").all()
    return render_template("admin_products.html", products=products)
@app.route("/admin/products/approve/<int:pid>")
def admin_product_approve(pid):
    p = Product.query.get(pid)
    p.status = "approved"
    db.session.commit()
    flash("Đã duyệt sản phẩm!", "success")
    return redirect(url_for("admin_products"))
@app.route("/admin/products/reject/<int:pid>")
def admin_product_reject(pid):
    p = Product.query.get(pid)
    p.status = "rejected"
    db.session.commit()
    flash("Đã từ chối sản phẩm!", "danger")
    return redirect(url_for("admin_products"))


@app.route("/admin/workouts")
def admin_workouts():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    workouts = Workout.query.order_by(Workout.workout_id.desc()).all()
    return render_template("admin_workouts.html", workouts=workouts)


@app.route("/admin/workouts/create", methods=["GET", "POST"])
def admin_workout_create():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    sports = [
        ("football", "Bóng đá"),
        ("volleyball", "Bóng chuyền"),
        ("tabletennis", "Bóng bàn"),
        ("tennis", "Tennis"),
        ("running", "Chạy bộ"),
    ]

    if request.method == "POST":
        name = request.form.get("name")
        sport_type = request.form.get("sport_type")
        goal = request.form.get("goal")
        difficulty = request.form.get("difficulty")
        calories = request.form.get("calories")
        video_url = request.form.get("video_url")
        bmi_group = request.form.get("bmi_group")

        try:
            calories_val = int(calories) if calories else None
        except ValueError:
            calories_val = None

        w = Workout(
            name=name,
            sport_type=sport_type,
            goal=goal,
            difficulty=difficulty,
            calories=calories_val,
            video_url=video_url,
            bmi_group=bmi_group
        )
        db.session.add(w)
        db.session.commit()

        flash("Thêm bài tập thành công!", "success")
        return redirect(url_for("admin_workouts"))

    return render_template("admin_workout_create.html", sports=sports)


@app.route("/admin/workouts/edit/<int:wid>", methods=["GET", "POST"])
def admin_workout_edit(wid):
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    w = Workout.query.get(wid)
    if not w:
        flash("Bài tập không tồn tại.", "danger")
        return redirect(url_for("admin_workouts"))

    sports = [
        ("football", "Bóng đá"),
        ("volleyball", "Bóng chuyền"),
        ("tabletennis", "Bóng bàn"),
        ("tennis", "Tennis"),
        ("running", "Chạy bộ"),
    ]

    if request.method == "POST":
        w.name = request.form.get("name")
        w.sport_type = request.form.get("sport_type")
        w.goal = request.form.get("goal")
        w.difficulty = request.form.get("difficulty")
        try:
            w.calories = int(request.form.get("calories")) if request.form.get("calories") else None
        except ValueError:
            w.calories = None
        w.video_url = request.form.get("video_url")
        w.bmi_group = request.form.get("bmi_group")

        db.session.commit()
        flash("Cập nhật bài tập thành công.", "success")
        return redirect(url_for("admin_workouts"))

    return render_template("admin_workout_edit.html", workout=w, sports=sports)


@app.route("/admin/workouts/delete/<int:wid>", methods=["POST"])
def admin_workout_delete(wid):
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    w = Workout.query.get(wid)
    if not w:
        flash("Bài tập không tồn tại.", "danger")
        return redirect(url_for("admin_workouts"))

    try:
        db.session.delete(w)
        db.session.commit()
        flash("Đã xóa bài tập.", "success")
    except Exception:
        db.session.rollback()
        flash("Xóa thất bại.", "danger")

    return redirect(url_for("admin_workouts"))
@app.route("/admin/courts")
def admin_courts():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    courts = Court.query.filter_by(status="pending").all()
    return render_template("admin_courts.html", courts=courts)
@app.route("/admin/courts/approve/<int:cid>")
def admin_court_approve(cid):
    c = Court.query.get(cid)
    c.status = "approved"
    db.session.commit()
    flash("Đã duyệt sân!", "success")
    return redirect(url_for("admin_courts"))
@app.route("/admin/courts/reject/<int:cid>")
def admin_court_reject(cid):
    c = Court.query.get(cid)
    c.status = "rejected"
    db.session.commit()
    flash("Đã từ chối sân!", "danger")
    return redirect(url_for("admin_courts"))
@app.route("/admin/stats")
def admin_stats():
    if "admin_id" not in session:
        return redirect(url_for("admin_login"))

    stats = {
        "users": User.query.count(),
        "partners": Partner.query.count(),
        "products": Product.query.count(),
        "courts": Court.query.count(),
        "orders": Order.query.count(),
    }

    return render_template("admin_stats.html", stats=stats)
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")
@app.route("/user/workout/<int:workout_id>")
def workout_detail(workout_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    workout = Workout.query.get(workout_id)

    if not workout:
        flash("Không tìm thấy bài tập!", "danger")
        return redirect(url_for("user_workouts"))

    return render_template("workout_detail.html", workout=workout, user=user)

# ============================
#  LOGIN 3 TRONG 1
# ============================

@app.route("/login", methods=["GET", "POST"])
def login():
    # Nếu GET → mở giao diện login
    if request.method == "GET":
        return render_template("login.html")

    # Nếu POST → xử lý đăng nhập
    account = request.form["account"]
    password = request.form["password"]

    # 1) ADMIN LOGIN
    admin = Admin.query.filter_by(username=account).first()
    if admin and check_pw(password, admin.password):
        session["admin_id"] = admin.admin_id
        session["role"] = "admin"
        return redirect("/admin/home")

    # 2) PARTNER LOGIN
    partner = Partner.query.filter_by(email=account).first()
    if partner and check_pw(password, partner.password):
        if getattr(partner, "status", "active") != "active":
            return render_template("login.html", error="Tài khoản đối tác đã bị khóa.")

        session["partner_id"] = partner.partner_id
        session["role"] = "partner"
        return redirect("/partner/home")

    # 3) USER LOGIN – email hoặc MSSV
    user = User.query.filter((User.email == account) | (User.mssv == account)).first()
    if user and check_pw(password, user.password):
        if getattr(user, "status", "active") != "active":
            return render_template("login.html", error="Tài khoản của bạn đã bị khóa.")

        session["user_id"] = user.user_id
        session["role"] = "user"
        return redirect("/user/home")

    # Nếu sai hết 3
    return render_template("login.html", error="Sai tài khoản hoặc mật khẩu!")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")

    full_name = request.form["name"]
    email     = request.form["email"]
    mssv      = request.form["mssv"]
    password  = hash_pw(request.form["password"])

    # Check trùng
    if User.query.filter((User.email == email) | (User.mssv == mssv)).first():
        return render_template("register.html", error="Email hoặc MSSV đã tồn tại!")

    new_user = User(
        full_name=full_name,
        email=email,
        mssv=mssv,
        password=password,
        created_at=datetime.now(),
        status="active"
    )
    db.session.add(new_user)
    db.session.commit()

    flash("Đăng ký thành công! Hãy đăng nhập.", "success")
    return redirect("/login")
@app.route("/courts")
def courts_list():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    courts = Court.query.filter_by(status="approved").all()
    return render_template("user_courts.html", user=user, courts=courts)
@app.route("/courts/<int:court_id>")
def courts_detail(court_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    court = Court.query.filter_by(court_id=court_id, status="approved").first()

    if not court:
        flash("Sân không tồn tại!", "danger")
        return redirect(url_for("courts_list"))

    # compute availability for next 7 days (same logic)
    try:
        open_h = int(court.open_time.split(":")[0])
        close_h = int(court.close_time.split(":")[0])
    except Exception:
        open_h, close_h = 8, 20

    slots = [f"{h:02d}:00-{h+1:02d}:00" for h in range(open_h, close_h)]

    days = []
    from datetime import date, timedelta
    today = date.today()
    for i in range(7):
        d = today + timedelta(days=i)
        bks = CourtBooking.query.filter_by(court_id=court.court_id, booking_date=d, status='booked').all()
        booked = [b.time_slot for b in bks]
        free = [s for s in slots if s not in booked]
        days.append({"date": d, "booked": booked, "free": free})

    return render_template("court_detail.html", user=user, court=court, days=days)
@app.route("/courts/<int:court_id>/book", methods=["GET", "POST"])
def courts_book(court_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    court = Court.query.filter_by(court_id=court_id, status="approved").first()
    if not court:
        flash("Sân không tồn tại!", "danger")
        return redirect(url_for("courts_list"))

    if request.method == "POST":
        date_str = request.form.get("booking_date")
        timeslot = request.form.get("time_slot")

        try:
            booking_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        except Exception:
            flash("Ngày đặt không hợp lệ.", "danger")
            return redirect(url_for("courts_book", court_id=court_id))

        # Check trùng lịch
        exist = CourtBooking.query.filter_by(
            court_id=court_id,
            booking_date=booking_date,
            time_slot=timeslot
        ).first()

        if exist:
            flash("Khung giờ này đã có người đặt!", "danger")
            return redirect(url_for("courts_book", court_id=court_id))

        booking = CourtBooking(
            user_id=user.user_id,
            court_id=court_id,
            booking_date=booking_date,
            time_slot=timeslot,
            status="booked",
            created_at=datetime.now()
        )
        db.session.add(booking)
        db.session.commit()

        flash("Đặt sân thành công!", "success")
        return redirect(url_for("user_bookings"))

    return render_template("court_book.html", user=user, court=court)
@app.route("/user/sports")
def user_sports():
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    sports = [
        {"id": "football", "name": "⚽ Bóng đá"},
        {"id": "volleyball", "name": "🏐 Bóng chuyền"},
        {"id": "tabletennis", "name": "🏓 Bóng bàn"},
        {"id": "tennis", "name": "🎾 Tennis"},
        {"id": "running", "name": "🏃 Chạy bộ"},
    ]

    return render_template("user_sports.html", user=user, sports=sports)
@app.route("/user/sports/<sport_id>")
def sports_workouts(sport_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))

    # Lấy bài tập đúng môn
    workouts = Workout.query.filter_by(sport_type=sport_id).all()

    # map sport id to a friendly name for display
    sport_names = {
        "football": "Bóng đá",
        "volleyball": "Bóng chuyền",
        "tabletennis": "Bóng bàn",
        "tennis": "Tennis",
        "running": "Chạy bộ",
    }
    sport_name = sport_names.get(sport_id, sport_id)

    return render_template("sports_workouts.html",
                           user=user,
                           sport_id=sport_id,
                           sport_name=sport_name,
                           workouts=workouts)
@app.route("/user/sports/detail/<int:workout_id>")
def sports_workout_detail(workout_id):
    workout = Workout.query.get(workout_id)

    if not workout:
        flash("Bài tập không tồn tại!", "danger")
        return redirect(url_for("user_sports"))

    return render_template("sports_detail.html", workout=workout)


# ==================================================
#  CHẠY SERVER
# ==================================================
if __name__ == "__main__":
    app.run(debug=True)
